module.exports = {
  lintOnSave: true,
  publicPath: '',
  productionSourceMap: false
}
