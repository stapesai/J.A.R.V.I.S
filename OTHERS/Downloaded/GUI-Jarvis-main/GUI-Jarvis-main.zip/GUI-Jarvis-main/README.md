# GUI-Jarvis
place Model.h5 file into your python directory where lshotword is installed
